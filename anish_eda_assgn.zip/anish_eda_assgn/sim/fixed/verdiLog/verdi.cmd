verdiSetActWin -dock widgetDock_<Decl._Tree>
simSetSimulator "-vcssv" -exec "simv" -args "-ucli"
debImport "-dbdir" "simv.daidir"
debLoadSimResult /home/synopsis/anish_eda_assgn/sim/fixed/fixed.fsdb
wvCreateWindow
verdiWindowResize -win $_Verdi_1 "500" "182" "900" "700"
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
verdiSetActWin -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
srcHBSelect "tb_cmd_trigger.dut" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
wvGetSignalOpen -win $_nWave2
verdiSetActWin -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/burst_pending} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_ack} \
{/tb_cmd_trigger/dut/cmd_ack_sync} \
{/tb_cmd_trigger/dut/cmd_req} \
{/tb_cmd_trigger/dut/cmd_req_sync} \
{/tb_cmd_trigger/dut/done_ack} \
{/tb_cmd_trigger/dut/done_ack_sync} \
{/tb_cmd_trigger/dut/done_req} \
{/tb_cmd_trigger/dut/done_req_sync} \
{/tb_cmd_trigger/dut/e_state\[2:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 7 8 9 10 11 12 13 )} 
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/burst_pending} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_ack} \
{/tb_cmd_trigger/dut/cmd_ack_sync} \
{/tb_cmd_trigger/dut/cmd_req} \
{/tb_cmd_trigger/dut/cmd_req_sync} \
{/tb_cmd_trigger/dut/done_ack} \
{/tb_cmd_trigger/dut/done_ack_sync} \
{/tb_cmd_trigger/dut/done_req} \
{/tb_cmd_trigger/dut/done_req_sync} \
{/tb_cmd_trigger/dut/e_state\[2:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 7 8 9 10 11 12 13 )} 
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/burst_pending} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_ack} \
{/tb_cmd_trigger/dut/cmd_ack_sync} \
{/tb_cmd_trigger/dut/cmd_req} \
{/tb_cmd_trigger/dut/cmd_req_sync} \
{/tb_cmd_trigger/dut/done_ack} \
{/tb_cmd_trigger/dut/done_ack_sync} \
{/tb_cmd_trigger/dut/done_req} \
{/tb_cmd_trigger/dut/done_req_sync} \
{/tb_cmd_trigger/dut/e_state\[2:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 7 8 9 10 11 12 13 )} 
wvSetPosition -win $_nWave2 {("G1" 13)}
wvGetSignalClose -win $_nWave2
srcDeselectAll -win $_nTrace1
srcSelect -signal "producer_pulse_count" -line 26 -pos 2 -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 5)}
wvSetPosition -win $_nWave2 {("G1" 7)}
wvSetPosition -win $_nWave2 {("G1" 8)}
wvSetPosition -win $_nWave2 {("G1" 10)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 12)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G1" 12)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvAddSignal -win $_nWave2 "/tb_cmd_trigger/producer_pulse_count\[7:0\]"
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
srcDeselectAll -win $_nTrace1
verdiSetActWin -win $_nWave2
srcDeselectAll -win $_nTrace1
srcSelect -signal "exec_count" -line 25 -pos 2 -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcSelect -win $_nTrace1 -range {25 39 6 1 9 1}
srcDeselectAll -win $_nTrace1
srcSelect -signal "producer_pulse_count" -line 26 -pos 2 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "exec_count" -line 25 -pos 2 -win $_nTrace1
srcSelect -win $_nTrace1 -range {25 35 6 1 8 1}
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "exec_count" -line 25 -pos 2 -win $_nTrace1
srcSelect -win $_nTrace1 -range {25 44 6 1 10 1}
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "exec_count" -line 25 -pos 2 -win $_nTrace1
srcSelect -win $_nTrace1 -range {25 36 6 14 8 1}
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "exec_count" -line 25 -pos 2 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "exec_count" -line 25 -pos 2 -win $_nTrace1
srcAction -pos 24 5 4 -win $_nTrace1 -name "exec_count" -ctrlKey off
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 5)}
wvSetPosition -win $_nWave2 {("G1" 12)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G1" 12)}
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvAddSignal -win $_nWave2 "/tb_cmd_trigger/dut/exec_count\[7:0\]"
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G2" 1)}
srcDeselectAll -win $_nTrace1
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
verdiSetActWin -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/burst_pending} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_ack} \
{/tb_cmd_trigger/dut/cmd_ack_sync} \
{/tb_cmd_trigger/dut/cmd_req} \
{/tb_cmd_trigger/dut/cmd_req_sync} \
{/tb_cmd_trigger/dut/done_ack} \
{/tb_cmd_trigger/dut/done_ack_sync} \
{/tb_cmd_trigger/dut/done_req} \
{/tb_cmd_trigger/dut/done_req_sync} \
{/tb_cmd_trigger/dut/e_state\[2:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/producer_pulse_count\[7:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/burst_pending} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_ack} \
{/tb_cmd_trigger/dut/cmd_ack_sync} \
{/tb_cmd_trigger/dut/cmd_req} \
{/tb_cmd_trigger/dut/cmd_req_sync} \
{/tb_cmd_trigger/dut/done_ack} \
{/tb_cmd_trigger/dut/done_ack_sync} \
{/tb_cmd_trigger/dut/done_req} \
{/tb_cmd_trigger/dut/done_req_sync} \
{/tb_cmd_trigger/dut/e_state\[2:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/producer_pulse_count\[7:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvZoomAll -win $_nWave2
wvZoomAll -win $_nWave2
debExit
