verdiSetActWin -dock widgetDock_<Decl._Tree>
simSetSimulator "-vcssv" -exec "simv" -args "-ucli"
debImport "-dbdir" "simv.daidir"
debLoadSimResult /home/synopsis/anish_eda_assgn/sim/naive/naive.fsdb
wvCreateWindow
verdiWindowResize -win $_Verdi_1 "500" "182" "900" "700"
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
verdiSetActWin -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
srcDeselectAll -win $_nTrace1
srcSelect -signal "trigger_en" -line 8 -pos 1 -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
verdiSetActWin -win $_nWave2
srcDeselectAll -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcHBSelect "tb_cmd_trigger" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
wvGetSignalOpen -win $_nWave2
verdiSetActWin -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_pulse} \
{/tb_cmd_trigger/dut/cmd_sync} \
{/tb_cmd_trigger/dut/done_pulse} \
{/tb_cmd_trigger/dut/done_sync} \
{/tb_cmd_trigger/dut/e_state\[1:0\]} \
{/tb_cmd_trigger/dut/exec_cnt\[7:0\]} \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/dut/gap_cnt\[4:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 7 8 9 10 11 )} 
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_pulse} \
{/tb_cmd_trigger/dut/cmd_sync} \
{/tb_cmd_trigger/dut/done_pulse} \
{/tb_cmd_trigger/dut/done_sync} \
{/tb_cmd_trigger/dut/e_state\[1:0\]} \
{/tb_cmd_trigger/dut/exec_cnt\[7:0\]} \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/dut/gap_cnt\[4:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 7 8 9 10 11 )} 
wvSetPosition -win $_nWave2 {("G1" 11)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_pulse} \
{/tb_cmd_trigger/dut/cmd_sync} \
{/tb_cmd_trigger/dut/done_pulse} \
{/tb_cmd_trigger/dut/done_sync} \
{/tb_cmd_trigger/dut/e_state\[1:0\]} \
{/tb_cmd_trigger/dut/exec_cnt\[7:0\]} \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/dut/gap_cnt\[4:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_pulse} \
{/tb_cmd_trigger/dut/cmd_sync} \
{/tb_cmd_trigger/dut/done_pulse} \
{/tb_cmd_trigger/dut/done_sync} \
{/tb_cmd_trigger/dut/e_state\[1:0\]} \
{/tb_cmd_trigger/dut/exec_cnt\[7:0\]} \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/dut/gap_cnt\[4:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvGetSignalClose -win $_nWave2
srcHBSelect "tb_cmd_trigger" -win $_nTrace1
srcSetScope "tb_cmd_trigger" -delim "." -win $_nTrace1
srcHBSelect "tb_cmd_trigger" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcDeselectAll -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcSelect -win $_nTrace1 -range {33 33 5 5 1 5} -backward
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcHBSelect "tb_cmd_trigger.dut" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcDeselectAll -win $_nTrace1
srcSelect -signal "producer_pulse_count" -line 26 -pos 2 -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 5)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 7)}
wvSetPosition -win $_nWave2 {("G1" 8)}
wvSetPosition -win $_nWave2 {("G1" 9)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvAddSignal -win $_nWave2 "/tb_cmd_trigger/producer_pulse_count\[7:0\]"
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
verdiSetActWin -win $_nWave2
wvZoomAll -win $_nWave2
wvZoomAll -win $_nWave2
srcDeselectAll -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
verdiDockWidgetSetCurTab -dock widgetDock_<Message>
verdiSetActWin -dock widgetDock_<Message>
verdiDockWidgetSetCurTab -dock windowDock_nWave_2
verdiSetActWin -win $_nWave2
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 1446994.446281 -snap {("G1" 0)}
wvSelectSignal -win $_nWave2 {( "G1" 10 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvGetSignalSetScope -win $_nWave2 "/tb_cmd_trigger/dut"
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/tb_cmd_trigger/dut/burst_mode} \
{/tb_cmd_trigger/dut/clkA} \
{/tb_cmd_trigger/dut/clkB} \
{/tb_cmd_trigger/dut/cmd_pulse} \
{/tb_cmd_trigger/dut/cmd_sync} \
{/tb_cmd_trigger/dut/done_pulse} \
{/tb_cmd_trigger/dut/done_sync} \
{/tb_cmd_trigger/dut/e_state\[1:0\]} \
{/tb_cmd_trigger/dut/exec_cnt\[7:0\]} \
{/tb_cmd_trigger/dut/exec_count\[7:0\]} \
{/tb_cmd_trigger/dut/gap_cnt\[4:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/tb_cmd_trigger/producer_pulse_count\[7:0\]} \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvGetSignalClose -win $_nWave2
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
debExit
