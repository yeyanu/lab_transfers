/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Thu Nov 26 14:02:47 2026
/////////////////////////////////////////////////////////////


module cmd_trigger_top ( clkA, rstA_n, clkB, rstB_n, trigger_en, burst_mode, 
        exec_count, producer_pulse_count );
  output [7:0] exec_count;
  output [7:0] producer_pulse_count;
  input clkA, rstA_n, clkB, rstB_n, trigger_en, burst_mode;
  wire   cmd_ack_sync, burst_pending, cmd_req, cmd_req_sync, cmd_ack,
         done_ack_sync, done_req, done_req_sync, done_ack, l_state,
         \u_sync_cmd_req/ff1 , \u_sync_done_ack/ff1 , \u_sync_done_req/ff1 ,
         \u_sync_cmd_ack/ff1 , n64, n65, n66, n67, n68, n69, n70, n71, n72,
         n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86,
         n87, n88, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98, n99, n100,
         n101, n102, n103, n104, n105, n106, n107, n108, n109, n110, n111,
         n112, n113, n114, n115, n116, n117, n118, n119, n120, n121, n122,
         n123, n124, n125, n126, n127, n128, n129, n130, n131, n132, n133,
         n134, n135, n137, n138, n139, n140, n141, n142, n143, n144, n145,
         n146, n147, n148, n149, n150, n151, n152, n153, n154, n155, n156,
         n157, n158, n159, n160, n161, n162, n163, n164, n165, n166, n167,
         n168, n169, n170, n171, n172, n173, n174, n175, n176, n177, n178;
  wire   [4:0] gap_cnt;
  wire   [1:0] p_state;
  wire   [2:0] e_state;

  DFFR_X1 \u_sync_cmd_ack/ff2_reg  ( .D(\u_sync_cmd_ack/ff1 ), .CK(clkA), .RN(
        rstA_n), .Q(cmd_ack_sync) );
  DFFR_X1 \p_state_reg[0]  ( .D(n92), .CK(clkA), .RN(rstA_n), .Q(p_state[0]), 
        .QN(n168) );
  DFFR_X1 \p_state_reg[1]  ( .D(n93), .CK(clkA), .RN(rstA_n), .Q(p_state[1]), 
        .QN(n164) );
  DFFR_X1 burst_pending_reg ( .D(n94), .CK(clkA), .RN(rstA_n), .Q(
        burst_pending) );
  DFFR_X1 \gap_cnt_reg[3]  ( .D(n87), .CK(clkA), .RN(rstA_n), .Q(gap_cnt[3]), 
        .QN(n175) );
  DFFR_X1 \gap_cnt_reg[1]  ( .D(n91), .CK(clkA), .RN(rstA_n), .Q(gap_cnt[1]), 
        .QN(n161) );
  DFFR_X1 \gap_cnt_reg[4]  ( .D(n90), .CK(clkA), .RN(rstA_n), .Q(gap_cnt[4])
         );
  DFFR_X1 \gap_cnt_reg[0]  ( .D(n89), .CK(clkA), .RN(rstA_n), .QN(n163) );
  DFFR_X1 \gap_cnt_reg[2]  ( .D(n88), .CK(clkA), .RN(rstA_n), .QN(n167) );
  DFFR_X1 \prod_cnt_reg[0]  ( .D(n71), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[0]) );
  DFFR_X1 \prod_cnt_reg[1]  ( .D(n70), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[1]), .QN(n170) );
  DFFR_X1 \prod_cnt_reg[2]  ( .D(n69), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[2]) );
  DFFR_X1 \prod_cnt_reg[3]  ( .D(n68), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[3]), .QN(n172) );
  DFFR_X1 \prod_cnt_reg[4]  ( .D(n67), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[4]) );
  DFFR_X1 \prod_cnt_reg[5]  ( .D(n66), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[5]), .QN(n174) );
  DFFR_X1 \prod_cnt_reg[6]  ( .D(n65), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[6]) );
  DFFR_X1 \prod_cnt_reg[7]  ( .D(n64), .CK(clkA), .RN(rstA_n), .Q(
        producer_pulse_count[7]) );
  DFFR_X1 cmd_req_reg ( .D(n86), .CK(clkA), .RN(rstA_n), .Q(cmd_req), .QN(n176) );
  DFFR_X1 \u_sync_cmd_req/ff1_reg  ( .D(cmd_req), .CK(clkB), .RN(rstB_n), .Q(
        \u_sync_cmd_req/ff1 ) );
  DFFR_X1 \u_sync_cmd_req/ff2_reg  ( .D(\u_sync_cmd_req/ff1 ), .CK(clkB), .RN(
        rstB_n), .Q(cmd_req_sync) );
  DFFR_X1 \e_state_reg[0]  ( .D(n83), .CK(clkB), .RN(rstB_n), .Q(e_state[0]), 
        .QN(n178) );
  DFFR_X1 \e_state_reg[1]  ( .D(n84), .CK(clkB), .RN(rstB_n), .Q(e_state[1]), 
        .QN(n162) );
  DFFR_X1 \e_state_reg[2]  ( .D(n85), .CK(clkB), .RN(rstB_n), .Q(e_state[2]), 
        .QN(n166) );
  DFFR_X1 done_req_reg ( .D(n82), .CK(clkB), .RN(rstB_n), .Q(done_req) );
  DFFR_X1 \u_sync_done_req/ff1_reg  ( .D(done_req), .CK(clkA), .RN(rstA_n), 
        .Q(\u_sync_done_req/ff1 ) );
  DFFR_X1 \u_sync_done_req/ff2_reg  ( .D(\u_sync_done_req/ff1 ), .CK(clkA), 
        .RN(rstA_n), .Q(done_req_sync), .QN(n165) );
  DFFR_X1 l_state_reg ( .D(done_req_sync), .CK(clkA), .RN(rstA_n), .Q(l_state)
         );
  DFFR_X1 \exec_cnt_reg[7]  ( .D(n81), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[7]) );
  DFFR_X1 \exec_cnt_reg[0]  ( .D(n80), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[0]) );
  DFFR_X1 \exec_cnt_reg[1]  ( .D(n79), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[1]), .QN(n169) );
  DFFR_X1 \exec_cnt_reg[2]  ( .D(n78), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[2]) );
  DFFR_X1 \exec_cnt_reg[3]  ( .D(n77), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[3]), .QN(n171) );
  DFFR_X1 \exec_cnt_reg[4]  ( .D(n76), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[4]) );
  DFFR_X1 \exec_cnt_reg[5]  ( .D(n75), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[5]), .QN(n173) );
  DFFR_X1 \exec_cnt_reg[6]  ( .D(n74), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[6]) );
  DFFR_X1 done_ack_reg ( .D(n73), .CK(clkA), .RN(rstA_n), .Q(done_ack), .QN(
        n177) );
  DFFR_X1 \u_sync_done_ack/ff1_reg  ( .D(done_ack), .CK(clkB), .RN(rstB_n), 
        .Q(\u_sync_done_ack/ff1 ) );
  DFFR_X1 \u_sync_done_ack/ff2_reg  ( .D(\u_sync_done_ack/ff1 ), .CK(clkB), 
        .RN(rstB_n), .Q(done_ack_sync) );
  DFFR_X1 cmd_ack_reg ( .D(n72), .CK(clkB), .RN(rstB_n), .Q(cmd_ack) );
  DFFR_X1 \u_sync_cmd_ack/ff1_reg  ( .D(cmd_ack), .CK(clkA), .RN(rstA_n), .Q(
        \u_sync_cmd_ack/ff1 ) );
  NOR2_X1 U97 ( .A1(n164), .A2(n168), .ZN(n126) );
  NAND3_X1 U98 ( .A1(n163), .A2(n167), .A3(n161), .ZN(n116) );
  NOR3_X1 U99 ( .A1(gap_cnt[4]), .A2(gap_cnt[3]), .A3(n116), .ZN(n105) );
  NAND2_X1 U100 ( .A1(n126), .A2(n105), .ZN(n123) );
  NOR2_X1 U101 ( .A1(p_state[1]), .A2(p_state[0]), .ZN(n125) );
  NAND3_X1 U102 ( .A1(n105), .A2(n125), .A3(trigger_en), .ZN(n128) );
  NAND2_X1 U103 ( .A1(n123), .A2(n128), .ZN(n96) );
  NAND2_X1 U104 ( .A1(producer_pulse_count[0]), .A2(n96), .ZN(n154) );
  OAI21_X1 U105 ( .B1(n96), .B2(producer_pulse_count[0]), .A(n154), .ZN(n95)
         );
  INV_X1 U106 ( .A(n95), .ZN(n71) );
  INV_X1 U107 ( .A(n96), .ZN(n97) );
  OR3_X1 U108 ( .A1(n164), .A2(p_state[0]), .A3(cmd_ack_sync), .ZN(n122) );
  NAND2_X1 U109 ( .A1(n97), .A2(n122), .ZN(n103) );
  NOR2_X1 U110 ( .A1(n126), .A2(n125), .ZN(n104) );
  NAND2_X1 U111 ( .A1(burst_pending), .A2(n168), .ZN(n110) );
  OAI211_X1 U112 ( .C1(cmd_ack_sync), .C2(n103), .A(n104), .B(n110), .ZN(n98)
         );
  OAI21_X1 U113 ( .B1(p_state[0]), .B2(n103), .A(n98), .ZN(n99) );
  INV_X1 U114 ( .A(n99), .ZN(n92) );
  INV_X1 U115 ( .A(burst_mode), .ZN(n101) );
  NAND3_X1 U116 ( .A1(burst_pending), .A2(n128), .A3(n122), .ZN(n100) );
  OAI21_X1 U117 ( .B1(n128), .B2(n101), .A(n100), .ZN(n94) );
  NAND3_X1 U118 ( .A1(cmd_ack_sync), .A2(n164), .A3(p_state[0]), .ZN(n102) );
  OAI221_X1 U119 ( .B1(n164), .B2(n110), .C1(n164), .C2(n103), .A(n102), .ZN(
        n93) );
  OAI21_X1 U120 ( .B1(n105), .B2(n104), .A(n122), .ZN(n114) );
  OAI221_X1 U121 ( .B1(n126), .B2(n125), .C1(n126), .C2(trigger_en), .A(n114), 
        .ZN(n115) );
  OAI21_X1 U122 ( .B1(n163), .B2(n115), .A(n114), .ZN(n107) );
  INV_X1 U123 ( .A(n107), .ZN(n106) );
  INV_X1 U124 ( .A(n115), .ZN(n108) );
  NAND2_X1 U125 ( .A1(n108), .A2(n163), .ZN(n113) );
  AOI22_X1 U126 ( .A1(gap_cnt[1]), .A2(n106), .B1(n113), .B2(n161), .ZN(n91)
         );
  AOI21_X1 U127 ( .B1(gap_cnt[1]), .B2(n108), .A(n107), .ZN(n118) );
  OAI21_X1 U128 ( .B1(n167), .B2(n115), .A(n118), .ZN(n120) );
  OAI221_X1 U129 ( .B1(n120), .B2(gap_cnt[3]), .C1(n120), .C2(n108), .A(
        gap_cnt[4]), .ZN(n109) );
  OAI21_X1 U130 ( .B1(burst_pending), .B2(n122), .A(n109), .ZN(n90) );
  INV_X1 U131 ( .A(n110), .ZN(n111) );
  NAND3_X1 U132 ( .A1(p_state[1]), .A2(n111), .A3(n114), .ZN(n112) );
  OAI211_X1 U133 ( .C1(n114), .C2(n163), .A(n113), .B(n112), .ZN(n89) );
  NOR2_X1 U134 ( .A1(n116), .A2(n115), .ZN(n119) );
  INV_X1 U135 ( .A(n119), .ZN(n117) );
  OAI21_X1 U136 ( .B1(n118), .B2(n167), .A(n117), .ZN(n88) );
  AOI22_X1 U137 ( .A1(gap_cnt[3]), .A2(n120), .B1(n119), .B2(n175), .ZN(n121)
         );
  OAI21_X1 U138 ( .B1(burst_pending), .B2(n122), .A(n121), .ZN(n87) );
  INV_X1 U139 ( .A(n123), .ZN(n124) );
  AOI211_X1 U140 ( .C1(cmd_ack_sync), .C2(n164), .A(n125), .B(n124), .ZN(n129)
         );
  NOR2_X1 U141 ( .A1(n129), .A2(n126), .ZN(n127) );
  AOI22_X1 U142 ( .A1(n176), .A2(n129), .B1(n128), .B2(n127), .ZN(n86) );
  NAND2_X1 U143 ( .A1(done_ack_sync), .A2(n162), .ZN(n149) );
  INV_X1 U144 ( .A(n149), .ZN(n130) );
  NOR2_X1 U145 ( .A1(e_state[0]), .A2(n149), .ZN(n140) );
  NOR2_X1 U146 ( .A1(cmd_req_sync), .A2(n162), .ZN(n150) );
  AOI221_X1 U147 ( .B1(cmd_req_sync), .B2(n166), .C1(n140), .C2(e_state[2]), 
        .A(n150), .ZN(n134) );
  OAI221_X1 U148 ( .B1(n178), .B2(e_state[2]), .C1(n178), .C2(n130), .A(n134), 
        .ZN(n135) );
  NAND3_X1 U149 ( .A1(e_state[1]), .A2(e_state[0]), .A3(n166), .ZN(n138) );
  OAI221_X1 U150 ( .B1(n166), .B2(e_state[1]), .C1(n166), .C2(n135), .A(n138), 
        .ZN(n85) );
  AOI21_X1 U151 ( .B1(n166), .B2(n178), .A(n162), .ZN(n132) );
  NAND2_X1 U152 ( .A1(e_state[0]), .A2(n135), .ZN(n131) );
  AOI22_X1 U153 ( .A1(n135), .A2(n132), .B1(n162), .B2(n131), .ZN(n84) );
  NOR2_X1 U155 ( .A1(n162), .A2(n166), .ZN(n133) );
  OAI33_X1 U156 ( .A1(1'b0), .A2(n135), .A3(n178), .B1(e_state[0]), .B2(n134), 
        .B3(n133), .ZN(n83) );
  NAND2_X1 U157 ( .A1(e_state[1]), .A2(e_state[0]), .ZN(n137) );
  NAND3_X1 U158 ( .A1(n162), .A2(n166), .A3(n178), .ZN(n151) );
  NAND3_X1 U159 ( .A1(done_req), .A2(n137), .A3(n151), .ZN(n139) );
  OAI21_X1 U160 ( .B1(n140), .B2(n139), .A(n138), .ZN(n82) );
  NOR2_X1 U161 ( .A1(l_state), .A2(n165), .ZN(n142) );
  NAND2_X1 U162 ( .A1(n142), .A2(exec_count[0]), .ZN(n143) );
  NOR2_X1 U163 ( .A1(n143), .A2(n169), .ZN(n144) );
  NAND2_X1 U164 ( .A1(n144), .A2(exec_count[2]), .ZN(n145) );
  NOR2_X1 U165 ( .A1(n145), .A2(n171), .ZN(n146) );
  NAND2_X1 U166 ( .A1(n146), .A2(exec_count[4]), .ZN(n147) );
  NOR2_X1 U167 ( .A1(n147), .A2(n173), .ZN(n148) );
  NAND2_X1 U168 ( .A1(n148), .A2(exec_count[6]), .ZN(n141) );
  XNOR2_X1 U169 ( .A(exec_count[7]), .B(n141), .ZN(n81) );
  XOR2_X1 U170 ( .A(n142), .B(exec_count[0]), .Z(n80) );
  AOI21_X1 U171 ( .B1(n143), .B2(n169), .A(n144), .ZN(n79) );
  XOR2_X1 U172 ( .A(n144), .B(exec_count[2]), .Z(n78) );
  AOI21_X1 U173 ( .B1(n145), .B2(n171), .A(n146), .ZN(n77) );
  XOR2_X1 U174 ( .A(n146), .B(exec_count[4]), .Z(n76) );
  AOI21_X1 U175 ( .B1(n147), .B2(n173), .A(n148), .ZN(n75) );
  XOR2_X1 U176 ( .A(n148), .B(exec_count[6]), .Z(n74) );
  AOI21_X1 U177 ( .B1(l_state), .B2(n177), .A(n165), .ZN(n73) );
  OAI211_X1 U178 ( .C1(n150), .C2(e_state[0]), .A(e_state[2]), .B(n149), .ZN(
        n153) );
  NAND3_X1 U179 ( .A1(n153), .A2(n151), .A3(cmd_ack), .ZN(n152) );
  OAI21_X1 U180 ( .B1(e_state[1]), .B2(n153), .A(n152), .ZN(n72) );
  NOR2_X1 U181 ( .A1(n154), .A2(n170), .ZN(n155) );
  AOI21_X1 U182 ( .B1(n154), .B2(n170), .A(n155), .ZN(n70) );
  XOR2_X1 U183 ( .A(n155), .B(producer_pulse_count[2]), .Z(n69) );
  NAND2_X1 U184 ( .A1(n155), .A2(producer_pulse_count[2]), .ZN(n156) );
  NOR2_X1 U185 ( .A1(n156), .A2(n172), .ZN(n157) );
  AOI21_X1 U186 ( .B1(n156), .B2(n172), .A(n157), .ZN(n68) );
  XOR2_X1 U187 ( .A(n157), .B(producer_pulse_count[4]), .Z(n67) );
  NAND2_X1 U188 ( .A1(n157), .A2(producer_pulse_count[4]), .ZN(n158) );
  NOR2_X1 U189 ( .A1(n158), .A2(n174), .ZN(n159) );
  AOI21_X1 U190 ( .B1(n158), .B2(n174), .A(n159), .ZN(n66) );
  XOR2_X1 U191 ( .A(n159), .B(producer_pulse_count[6]), .Z(n65) );
  NAND2_X1 U192 ( .A1(n159), .A2(producer_pulse_count[6]), .ZN(n160) );
  XNOR2_X1 U193 ( .A(producer_pulse_count[7]), .B(n160), .ZN(n64) );
endmodule

