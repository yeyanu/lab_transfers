###################################################################

# Created by write_sdc on Thu Nov 26 14:02:47 2026

###################################################################
set sdc_version 2.1

set_units -time ns -resistance MOhm -capacitance fF -voltage V -current mA
create_clock [get_ports clkA]  -period 10  -waveform {0 5}
set_clock_uncertainty 0.2  [get_clocks clkA]
create_clock [get_ports clkB]  -period 33.7  -waveform {0 16.85}
set_clock_uncertainty 0.2  [get_clocks clkB]
set_input_delay -clock clkA  1  [get_ports trigger_en]
set_input_delay -clock clkA  1  [get_ports burst_mode]
set_input_delay -clock clkA  1  [get_ports rstA_n]
set_input_delay -clock clkB  2  [get_ports rstB_n]
set_output_delay -clock clkA  1  [get_ports {exec_count[7]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[6]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[5]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[4]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[3]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[2]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[1]}]
set_output_delay -clock clkA  1  [get_ports {exec_count[0]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[7]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[6]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[5]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[4]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[3]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[2]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[1]}]
set_output_delay -clock clkA  1  [get_ports {producer_pulse_count[0]}]
set_clock_groups  -asynchronous -name clkA_1  -group [get_clocks clkA] -group  \
[get_clocks clkB]
